package com.example.patrones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatronesApplicationTests {

	@Test
	void contextLoads() {
	}

}
